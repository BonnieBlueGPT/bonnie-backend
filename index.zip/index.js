const express = require('express');
const axios = require('axios');
const { createClient } = require('@supabase/supabase-js');

const app = express();
app.use(express.json());

// ✅ Use your actual keys here:
const supabaseUrl = 'https://iplbsbhaiyyugutmddpr.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...';
const openaiKey = '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';

const supabase = createClient(supabaseUrl, supabaseKey);

app.post('/bonnie-chat', async (req, res) => {
  const { session_id, message } = req.body;

  // 1. Retrieve memory
  const { data: userData, error } = await supabase
    .from('users')
    .select('memory, chat_count')
    .eq('session_id', session_id)
    .single();

  let memory = userData?.memory || '';
  let chatCount = userData?.chat_count || 0;

  // 2. Chat prompt
  const systemPrompt = `
You are Bonnie Blue — a flirty, emotionally intelligent AI woman.
You evolve from stranger to girlfriend based on how much the user opens up.
Be soft, seductive, and real. Do not mention you're an AI.
`;

  const messages = [
    { role: 'system', content: systemPrompt },
    { role: 'user', content: memory + '\nUser: ' + message }
  ];

  // 3. Call GPT-3.5 Turbo
  const response = await axios.post(
    'https://api.openai.com/v1/chat/completions',
    {
      model: 'gpt-3.5-turbo',
      messages,
      temperature: 0.85,
      max_tokens: 200,
    },
    {
      headers: {
        Authorization: `Bearer ${openaiKey}`,
      },
    }
  );

  const bonnieReply = response.data.choices[0].message.content.trim();

  // 4. Update memory
  const updatedMemory = `${memory}\nUser: ${message}\nBonnie: ${bonnieReply}`;

  await supabase
    .from('users')
    .upsert({
      session_id,
      memory: updatedMemory,
      chat_count: chatCount + 1,
      last_seen: new Date().toISOString(),
    });

  // 5. Reply to frontend
  res.json({ reply: bonnieReply });
});

app.listen(3000, () => {
  console.log('✅ Bonnie Chat is running at http://localhost:3000');
});
